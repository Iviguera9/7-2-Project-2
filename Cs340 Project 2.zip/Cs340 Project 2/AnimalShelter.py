from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps


class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:5992' % ("aacuser", "SNHU1234"))
        self.database = self.client["AAC"]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            create = self.database.animals.insert(data)  # data should be dictionary
            if create != 0:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, read = None):
        if read is not None:
            data = self.database.animals.find(read,{"_id": False})
            
        else:
            data = self.database.animals.find({},{"_id": False})
        
        return data
    
# Create method to implement the U in CRUD.
    def update(self, data, update):
        if data is not None:
            if self.database.animals.count_documents(data, limit = 1) != 0:
                updated = self.database.animals.update_many(data, {"$set": update})
                target = updated.raw_result

                return target
        else:
            raise Exception("Failed to update current data")

# Create method to implement the D in CRUD.
    def delete(self, delete):
        if delete is not None:
            if self.database.animals.count_documents(delete, limit = 1) != 0:
                deleted = self.database.animals.delete_many(delete)
                target = deleted.raw_result

            return target
        else:
            raise Exception("Failed to delete current data")